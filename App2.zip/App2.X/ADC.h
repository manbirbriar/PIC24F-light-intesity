#ifndef ADC_H
#define ADC_H

#include <xc.h>

// Function declarations
uint16_t do_ADC(void);


#endif 