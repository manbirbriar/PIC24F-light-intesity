#ifndef TIMEDELAY_H
#define TIMDELAY_H
#include <xc.h>

void delay_ms(float time_ms);

#endif